#include <Connections.h>



Connections::Connections(): username(""), channeltoUniqueID() , receiptToOriginalMsg(){}

